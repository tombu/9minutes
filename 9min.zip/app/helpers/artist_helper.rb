module ArtistHelper
end
