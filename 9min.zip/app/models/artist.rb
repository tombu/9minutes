class Artist < ActiveRecord::Base
end
