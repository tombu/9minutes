class YoutubeVideoRating < ActiveRecord::Base
end
