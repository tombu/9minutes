class SidebarController < ApplicationController
  def index
  end

end
