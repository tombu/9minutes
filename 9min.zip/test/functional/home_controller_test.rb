require 'test_helper'

class HomeControllerTest < ActionController::TestCase

end
