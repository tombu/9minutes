require 'test_helper'

class ArtistControllerTest < ActionController::TestCase

end
