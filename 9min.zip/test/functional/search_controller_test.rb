require 'test_helper'

class SearchControllerTest < ActionController::TestCase

end
