require 'test_helper'

class TracksControllerTest < ActionController::TestCase

end
