require 'test_helper'

class SidebarHelperTest < ActionView::TestCase
end
