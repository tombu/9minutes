require 'test_helper'

class ArtistHelperTest < ActionView::TestCase
end
