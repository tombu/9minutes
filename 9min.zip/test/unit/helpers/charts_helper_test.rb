require 'test_helper'

class ChartsHelperTest < ActionView::TestCase
end
